
document.addEventListener("DOMContentLoaded", () => {
    const listItems = document.querySelectorAll("li");

    listItems.forEach((item) => {
        item.addEventListener("click", () => {
            item.style.backgroundColor = "#f1f8e9";
            setTimeout(() => {
                item.style.backgroundColor = "white";
            }, 300);
        });
    });

    console.log("Admin Dashboard Loaded");
});
